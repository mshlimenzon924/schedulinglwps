#ifndef RR
#define RR
#include "Asgn2/include/lwp.h"
#include "Asgn2/include/fp.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/time.h>
#include <unistd.h>

typedef struct Node {
    thread current_thread;
    struct Node *next;
} Node;

typedef struct Queue {
    struct Node *head;
    struct Node *tail;
} Queue;


void rr_init();
void rr_shutdown();
void rr_admit(thread new);
void rr_remove(thread victim);
thread rr_next();
int rr_qlen(void);
void rr_enqueue(thread new);
struct Node* rr_dequeue();
void print_queue();

struct Queue *queue;
extern struct scheduler roundrobin;
extern scheduler current_scheduler;

# endif
